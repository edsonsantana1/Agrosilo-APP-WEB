/**
 * JavaScript para a tela de login do Agrosilo
 * 
 * Funcionalidades:
 * - Gerenciar formulários de login e cadastro
 * - Validação de campos
 * - Formatação de telefone
 * - Modal de gerenciamento de usuários
 * - Notificações e mensagens
 */

document.addEventListener('DOMContentLoaded', function() {
    // Verificar se já está logado
    if (isAuthenticated()) {
        window.location.href = 'pages/dashboard.html';
        return;
    }

    initializeLoginPage();
});

/**
 * Inicializa a página de login
 */
function initializeLoginPage() {
    setupFormHandlers();
    setupPhoneFormatting();
    setupPasswordToggle();
    setupFormValidation();
}

/**
 * Configura os manipuladores de formulário
 */
function setupFormHandlers() {
    // Formulário de login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Formulário de cadastro
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
}

/**
 * Manipula o envio do formulário de login
 */
async function handleLogin(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const email = formData.get('email');
    const password = formData.get('password');
    const role = formData.get('role');

    // Validar campos
    if (!validateLoginForm(email, password, role)) {
        return;
    }

    // Mostrar loading
    const submitButton = event.target.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<div class="loading"></div> Entrando...';
    submitButton.disabled = true;

    try {
        const result = await login(email, password, role);
        
        if (result.success) {
            showMessage('success', MESSAGES.success.login);
            
            // Verificar se é admin e mostrar modal se necessário
            if (result.user.role === 'admin') {
                setTimeout(() => {
                    showUserManagementModal();
                }, 1000);
            } else {
                // Redirecionar para dashboard
                setTimeout(() => {
                    window.location.href = 'pages/dashboard.html';
                }, 1500);
            }
        } else {
            showMessage('error', result.error);
        }
    } catch (error) {
        showMessage('error', MESSAGES.error.generic);
        console.error('Erro no login:', error);
    } finally {
        // Restaurar botão
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
    }
}

/**
 * Manipula o envio do formulário de cadastro
 */
async function handleRegister(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const userData = {
        name: formData.get('name'),
        email: formData.get('email'),
        password: formData.get('password'),
        phoneNumber: formData.get('phoneNumber')
    };

    // Validar campos
    if (!validateRegisterForm(userData)) {
        return;
    }

    // Mostrar loading
    const submitButton = event.target.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<div class="loading"></div> Criando conta...';
    submitButton.disabled = true;

    try {
        const result = await register(userData);
        
        if (result.success) {
            showMessage('success', MESSAGES.success.register);
            
            // Voltar para o formulário de login após 2 segundos
            setTimeout(() => {
                showLoginForm();
                // Preencher email no formulário de login
                document.getElementById('email').value = userData.email;
            }, 2000);
        } else {
            showMessage('error', result.error);
        }
    } catch (error) {
        showMessage('error', MESSAGES.error.generic);
        console.error('Erro no cadastro:', error);
    } finally {
        // Restaurar botão
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
    }
}

/**
 * Valida o formulário de login
 */
function validateLoginForm(email, password, role) {
    let isValid = true;

    // Validar email
    if (!email || !Utils.validateEmail(email)) {
        setFieldError('email', 'Digite um email válido');
        isValid = false;
    } else {
        setFieldSuccess('email');
    }

    // Validar senha
    if (!password || password.length < VALIDATION_CONFIG.password.minLength) {
        setFieldError('password', VALIDATION_CONFIG.password.message);
        isValid = false;
    } else {
        setFieldSuccess('password');
    }

    // Validar role
    if (!role) {
        setFieldError('role', 'Selecione o tipo de usuário');
        isValid = false;
    } else {
        setFieldSuccess('role');
    }

    return isValid;
}

/**
 * Valida o formulário de cadastro
 */
function validateRegisterForm(userData) {
    let isValid = true;

    // Validar nome
    if (!userData.name || userData.name.trim().length < 2) {
        setFieldError('registerName', 'Nome deve ter pelo menos 2 caracteres');
        isValid = false;
    } else {
        setFieldSuccess('registerName');
    }

    // Validar email
    if (!userData.email || !Utils.validateEmail(userData.email)) {
        setFieldError('registerEmail', VALIDATION_CONFIG.email.message);
        isValid = false;
    } else {
        setFieldSuccess('registerEmail');
    }

    // Validar senha
    if (!userData.password || userData.password.length < VALIDATION_CONFIG.password.minLength) {
        setFieldError('registerPassword', VALIDATION_CONFIG.password.message);
        isValid = false;
    } else {
        setFieldSuccess('registerPassword');
    }

    // Validar telefone
    if (!userData.phoneNumber || !Utils.validatePhone(userData.phoneNumber)) {
        setFieldError('phoneNumber', VALIDATION_CONFIG.phone.message);
        isValid = false;
    } else {
        setFieldSuccess('phoneNumber');
    }

    return isValid;
}

/**
 * Define erro em um campo
 */
function setFieldError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const formGroup = field.closest('.form-group');
    
    formGroup.classList.remove('success');
    formGroup.classList.add('error');
    
    // Remover mensagem de erro anterior
    const existingError = formGroup.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    
    // Adicionar nova mensagem de erro
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
    formGroup.appendChild(errorDiv);
}

/**
 * Define sucesso em um campo
 */
function setFieldSuccess(fieldId) {
    const field = document.getElementById(fieldId);
    const formGroup = field.closest('.form-group');
    
    formGroup.classList.remove('error');
    formGroup.classList.add('success');
    
    // Remover mensagem de erro
    const existingError = formGroup.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
}

/**
 * Configura formatação automática do telefone
 */
function setupPhoneFormatting() {
    const phoneInput = document.getElementById('phoneNumber');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            
            if (value.length <= 11) {
                if (value.length > 6) {
                    value = `(${value.slice(0, 2)}) ${value.slice(2, 7)}-${value.slice(7)}`;
                } else if (value.length > 2) {
                    value = `(${value.slice(0, 2)}) ${value.slice(2)}`;
                }
                
                e.target.value = value;
            }
        });
    }
}

/**
 * Configura toggle de senha
 */
function setupPasswordToggle() {
    const toggleButtons = document.querySelectorAll('.password-toggle');
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const input = this.previousElementSibling;
            const icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
}

/**
 * Configura validação em tempo real
 */
function setupFormValidation() {
    // Validação em tempo real para campos de email
    const emailInputs = document.querySelectorAll('input[type="email"]');
    emailInputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (this.value && !Utils.validateEmail(this.value)) {
                setFieldError(this.id, VALIDATION_CONFIG.email.message);
            } else if (this.value) {
                setFieldSuccess(this.id);
            }
        });
    });

    // Validação em tempo real para telefone
    const phoneInput = document.getElementById('phoneNumber');
    if (phoneInput) {
        phoneInput.addEventListener('blur', function() {
            if (this.value && !Utils.validatePhone(this.value)) {
                setFieldError(this.id, VALIDATION_CONFIG.phone.message);
            } else if (this.value) {
                setFieldSuccess(this.id);
            }
        });
    }
}

/**
 * Mostra o formulário de cadastro
 */
function showRegisterForm() {
    document.querySelector('.login-form-container').style.display = 'none';
    document.getElementById('registerContainer').style.display = 'block';
    clearMessages();
}

/**
 * Mostra o formulário de login
 */
function showLoginForm() {
    document.querySelector('.login-form-container').style.display = 'block';
    document.getElementById('registerContainer').style.display = 'none';
    clearMessages();
}

/**
 * Mostra modal de esqueci senha (placeholder)
 */
function showForgotPassword() {
    showMessage('info', 'Funcionalidade em desenvolvimento. Entre em contato com o administrador.');
}

/**
 * Mostra mensagem na tela
 */
function showMessage(type, message) {
    const container = document.getElementById('messageContainer');
    
    // Limpar mensagens anteriores
    container.innerHTML = '';
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${type}`;
    
    const icon = getMessageIcon(type);
    messageDiv.innerHTML = `<i class="${icon}"></i> ${message}`;
    
    container.appendChild(messageDiv);
    
    // Auto-remover após 5 segundos
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, NOTIFICATION_CONFIG.duration);
}

/**
 * Retorna ícone da mensagem baseado no tipo
 */
function getMessageIcon(type) {
    const icons = {
        success: 'fas fa-check-circle',
        error: 'fas fa-exclamation-circle',
        info: 'fas fa-info-circle',
        warning: 'fas fa-exclamation-triangle'
    };
    return icons[type] || icons.info;
}

/**
 * Limpa todas as mensagens
 */
function clearMessages() {
    const container = document.getElementById('messageContainer');
    container.innerHTML = '';
}

/**
 * Mostra modal de gerenciamento de usuários
 */
async function showUserManagementModal() {
    const modal = document.getElementById('userManagementModal');
    const usersList = document.getElementById('usersList');
    
    try {
        // Buscar usuários
        usersList.innerHTML = '<div class="loading"></div> Carregando usuários...';
        modal.style.display = 'block';
        
        const users = await authManager.getUsers();
        
        // Renderizar lista de usuários
        usersList.innerHTML = '';
        users.forEach(user => {
            const userItem = createUserItem(user);
            usersList.appendChild(userItem);
        });
        
    } catch (error) {
        usersList.innerHTML = '<p>Erro ao carregar usuários</p>';
        console.error('Erro ao buscar usuários:', error);
    }
}

/**
 * Cria item de usuário para a lista
 */
function createUserItem(user) {
    const div = document.createElement('div');
    div.className = 'user-item';
    div.innerHTML = `
        <div class="user-info">
            <h4>${user.name}</h4>
            <p>${user.email} - ${user.role === 'admin' ? 'Administrador' : 'Usuário'}</p>
            <p>Tel: ${Utils.formatPhone(user.phoneNumber || 'Não informado')}</p>
        </div>
        <div class="user-actions">
            <button class="btn-small btn-edit" onclick="editUser('${user._id}')">
                <i class="fas fa-edit"></i> Editar
            </button>
            <button class="btn-small btn-delete" onclick="deleteUser('${user._id}')">
                <i class="fas fa-trash"></i> Excluir
            </button>
        </div>
    `;
    return div;
}

/**
 * Fecha modal de gerenciamento de usuários
 */
function closeUserManagementModal() {
    document.getElementById('userManagementModal').style.display = 'none';
    
    // Redirecionar para dashboard após fechar modal
    setTimeout(() => {
        window.location.href = 'pages/dashboard.html';
    }, 500);
}

/**
 * Edita usuário (placeholder)
 */
function editUser(userId) {
    showMessage('info', 'Funcionalidade de edição em desenvolvimento');
}

/**
 * Exclui usuário
 */
async function deleteUser(userId) {
    if (!confirm('Tem certeza que deseja excluir este usuário?')) {
        return;
    }
    
    try {
        await authManager.deleteUser(userId);
        showMessage('success', MESSAGES.success.delete);
        
        // Recarregar lista de usuários
        setTimeout(() => {
            showUserManagementModal();
        }, 1000);
        
    } catch (error) {
        showMessage('error', 'Erro ao excluir usuário');
        console.error('Erro ao excluir usuário:', error);
    }
}

/**
 * Toggle de senha global
 */
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.getElementById('passwordToggleIcon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('fa-eye');
        toggleIcon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('fa-eye-slash');
        toggleIcon.classList.add('fa-eye');
    }
}

// Fechar modal ao clicar fora
window.addEventListener('click', function(event) {
    const modal = document.getElementById('userManagementModal');
    if (event.target === modal) {
        closeUserManagementModal();
    }
});

