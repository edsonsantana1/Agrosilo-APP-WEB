/**
 * analysis.js
 * Página de análise de dados históricos do Agrosilo.
 * - Carrega silos
 * - Busca histórico
 * - Renderiza gráfico (Chart.js)
 * - Gera relatório PDF
 */

// ------------ Fallbacks robustos (caso utils.js não carregue) ------------
const U = (() => {
  const hasUtils = typeof window !== "undefined" && window.Utils && typeof window.Utils === "object";
  const fmt = (d, opts = {}) => {
    try {
      const date = new Date(d);
      const defaultOpts = { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" };
      return new Intl.DateTimeFormat("pt-BR", { ...defaultOpts, ...opts }).format(date);
    } catch {
      return String(d);
    }
  };
  const sensorCfg = (t) => {
    switch (t) {
      case "temperature": return { displayName: "Temperatura", unit: "°C",  color: "rgb(255, 99, 132)" };
      case "humidity":   return { displayName: "Umidade",     unit: "%",   color: "rgb(54, 162, 235)" };
      case "pressure":   return { displayName: "Pressão Atmosférica", unit: "hPa", color: "rgb(75, 192, 192)" };
      case "co2":        return { displayName: "Gás CO2",      unit: "ppm", color: "rgb(153, 102, 255)" };
      default:           return { displayName: t, unit: "", color: "rgb(201, 203, 207)" };
    }
  };
  const notify = (type, message) => {
    if (hasUtils && typeof window.Utils.showNotification === "function") {
      window.Utils.showNotification(type, message);
      return;
    }
    console.warn("[analysis.js] Utils.showNotification ausente. Mensagem:", type, message);
    if (type === "error" || type === "warning") alert(`${type.toUpperCase()}: ${message}`);
    else console.log(`[${type}]`, message);
  };

  return {
    showNotification: notify,
    formatDate: hasUtils && typeof window.Utils.formatDate === "function" ? window.Utils.formatDate : fmt,
    getSensorConfig: hasUtils && typeof window.Utils.getSensorConfig === "function" ? window.Utils.getSensorConfig : sensorCfg
  };
})();

// ------------ Estado ------------
let sensorChart = null;

// ------------ Boot ------------
document.addEventListener("DOMContentLoaded", function () {
  if (!requireAuth()) return;
  initializeAnalysisPage();
});

// ------------ Fluxo principal ------------
async function initializeAnalysisPage() {
  setupUserInterface();
  await loadSilosForAnalysis();
  setupEventHandlers();
  showChartEmptyState();
}

function setupUserInterface() {
  const user = getCurrentUser();
  document.getElementById("userName").textContent = user.name || "Usuário";
  document.getElementById("userRole").textContent = user.role === "admin" ? "Administrador" : "Usuário";
  if (isAdmin()) document.getElementById("usersMenuItem").style.display = "flex";
}

// Tenta /silos (rota já existente no backend). Se falhar, tenta /analysis/silos.
async function fetchSilosResiliente() {
  try {
    const silos = await authManager.makeRequest("/silos"); // authManager prefixa /api
    return silos;
  } catch (e1) {
    console.warn("[analysis] Falhou /silos, tentando /analysis/silos…", e1);
    try {
      const silosAlt = await authManager.makeRequest("/analysis/silos");
      return silosAlt;
    } catch (e2) {
      console.error("[analysis] Falhou também /analysis/silos.", e2);
      throw e2;
    }
  }
}

async function loadSilosForAnalysis() {
  const siloSelect = document.getElementById("siloSelect");
  siloSelect.innerHTML = '<option value="">Selecione um Silo</option>';

  try {
    const silos = await fetchSilosResiliente();
    console.log("[analysis] Silos recebidos:", silos);

    (silos || []).forEach((silo) => {
      const opt = document.createElement("option");
      opt.value = silo._id;
      opt.textContent = silo.name;
      siloSelect.appendChild(opt);
    });

    if (!silos || silos.length === 0) {
      U.showNotification("info", "Você ainda não tem silos cadastrados (ou não há permissão).");
    }
  } catch (error) {
    console.error("Erro ao carregar silos para análise:", error);
    U.showNotification("error", "Erro ao carregar silos para análise.");
  }
}

async function loadChartData() {
  const siloId = document.getElementById("siloSelect").value;
  const sensorType = document.getElementById("sensorTypeSelect").value;
  const dateRange = document.getElementById("dateRangeSelect").value;

  if (!siloId) {
    U.showNotification("warning", "Por favor, selecione um silo.");
    return;
  }

  try {
    U.showNotification("info", "Carregando dados...");
    const data = await authManager.makeRequest(
      `/analysis/history/${encodeURIComponent(siloId)}/${encodeURIComponent(sensorType)}?range=${encodeURIComponent(dateRange)}`
    );

    if (!Array.isArray(data) || data.length === 0) {
      U.showNotification("info", "Nenhum dado encontrado para o período selecionado.");
      showChartEmptyState();
      return;
    }

    hideChartEmptyState();
    renderChart(data, sensorType);
    U.showNotification("success", "Dados carregados com sucesso!");
  } catch (error) {
    console.error("Erro ao carregar dados do sensor:", error);
    U.showNotification("error", "Erro ao carregar dados do sensor.");
    showChartEmptyState();
  }
}

function renderChart(data, sensorType) {
  const canvas = document.getElementById("sensorChart");
  if (!canvas) {
    console.error("Canvas #sensorChart não encontrado.");
    return;
  }
  const ctx = canvas.getContext("2d");
  if (sensorChart) sensorChart.destroy();

  const labels = data.map((item) =>
    U.formatDate(item.timestamp, { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" })
  );
  const values = data.map((item) => item.value);
  const sensorConfig = U.getSensorConfig(sensorType);

  sensorChart = new Chart(ctx, {
    type: "line",
    data: {
      labels,
      datasets: [
        {
          label: `${sensorConfig.displayName} (${sensorConfig.unit})`,
          data: values,
          borderColor: sensorConfig.color,
          backgroundColor: sensorConfig.color.replace("rgb", "rgba").replace(")", ", 0.2)"),
          borderWidth: 2,
          pointRadius: 3,
          fill: true,
          tension: 0.3
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { title: { display: true, text: "Data/Hora" } },
        y: { title: { display: true, text: `${sensorConfig.displayName} (${sensorConfig.unit})` } }
      },
      plugins: {
        tooltip: {
          callbacks: {
            label: (ctx) => `${ctx.dataset.label}: ${ctx.raw}`
          }
        }
      }
    }
  });
}

async function generateReport() {
  const siloId = document.getElementById("siloSelect").value;
  const sensorType = document.getElementById("sensorTypeSelect").value;
  const dateRange = document.getElementById("dateRangeSelect").value;

  if (!siloId) {
    window.Utils?.showNotification?.("warning", "Selecione um silo para gerar o relatório.");
    return;
  }

  try {
    window.Utils?.showNotification?.("info", "Gerando relatório PDF...");
    const apiBase = (window.API_CONFIG?.baseURL || "http://localhost:4000/api");
    const url = `${apiBase}/analysis/report?siloId=${encodeURIComponent(siloId)}&sensorType=${encodeURIComponent(sensorType)}&range=${encodeURIComponent(dateRange)}`;
    const resp = await fetch(url, { headers: { Authorization: `Bearer ${authManager.getToken()}` } });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const blob = await resp.blob();
    const fileURL = URL.createObjectURL(blob);
    window.open(fileURL);
    window.Utils?.showNotification?.("success", "Relatório PDF gerado com sucesso!");
  } catch (err) {
    console.error("Erro ao gerar relatório:", err);
    window.Utils?.showNotification?.("error", "Erro ao gerar relatório PDF.");
  }
}


// ------------ UI helpers ------------
function showChartEmptyState() {
  document.getElementById("sensorChart").style.display = "none";
  document.getElementById("chartEmptyState").style.display = "flex";
}
function hideChartEmptyState() {
  document.getElementById("sensorChart").style.display = "block";
  document.getElementById("chartEmptyState").style.display = "none";
}
function setupEventHandlers() {
  // (adicione listeners se necessário)
}
