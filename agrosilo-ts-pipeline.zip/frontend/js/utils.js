/**
 * utils.js
 * Funções utilitárias globais para o frontend do Agrosilo.
 */

// Configurações de notificação
const NOTIFICATION_CONFIG = {
    duration: 5000 // Duração padrão da notificação em milissegundos
};

// Configurações da API (assumindo que API_BASE_URL está definida em config.js)
const API_CONFIG = {
    baseURL: API_BASE_URL || "http://localhost:4000/api" // Fallback para desenvolvimento
};

// Configurações de autenticação (chaves para localStorage)
const AUTH_CONFIG = {
    tokenKey: "jwtToken",
    userKey: "currentUser"
};

// Mensagens de erro e sucesso
const MESSAGES = {
    error: {
        network: "Erro de conexão. Verifique sua internet ou o servidor.",
        login: "Email ou senha inválidos.",
        register: "Erro ao registrar usuário. Tente novamente.",
        unauthorized: "Sessão expirada ou não autorizado. Faça login novamente."
    },
    success: {
        login: "Login realizado com sucesso!",
        register: "Usuário registrado com sucesso!",
        logout: "Logout realizado com sucesso."
    }
};

const Utils = {
    /**
     * Formata uma data para exibição.
     * @param {string | Date} dateInput - A data a ser formatada.
     * @param {Object} options - Opções de formatação do Intl.DateTimeFormat.
     * @returns {string}
     */
    formatDate: function(dateInput, options = {}) {
        const date = new Date(dateInput);
        const defaultOptions = {
            year: "numeric", 
            month: "long",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit"
        };
        return new Intl.DateTimeFormat("pt-BR", { ...defaultOptions, ...options }).format(date);
    },

    /**
     * Retorna o nome de exibição de um tipo de sensor.
     * @param {string} sensorType - O tipo de sensor (e.g., "temperature").
     * @returns {string}
     */
    getSensorDisplayName: function(sensorType) {
        switch (sensorType) {
            case "temperature":
                return "Temperatura";
            case "humidity":
                return "Umidade";
            case "pressure":
                return "Pressão Atmosférica";
            case "co2":
                return "Gás CO2";
            default:
                return sensorType;
        }
    },

    /**
     * Retorna configurações específicas para um tipo de sensor (cor, unidade).
     * @param {string} sensorType - O tipo de sensor.
     * @returns {Object}
     */
    getSensorConfig: function(sensorType) {
        switch (sensorType) {
            case "temperature":
                return { displayName: "Temperatura", unit: "°C", color: "rgb(255, 99, 132)" };
            case "humidity":
                return { displayName: "Umidade", unit: "%", color: "rgb(54, 162, 235)" };
            case "pressure":
                return { displayName: "Pressão Atmosférica", unit: "hPa", color: "rgb(75, 192, 192)" };
            case "co2":
                return { displayName: "Gás CO2", unit: "ppm", color: "rgb(153, 102, 255)" };
            default:
                return { displayName: sensorType, unit: "", color: "rgb(201, 203, 207)" };
        }
    },

    /**
     * Mostra uma notificação na tela.
     * @param {string} type - Tipo da notificação ("success", "error", "warning", "info").
     * @param {string} message - Mensagem da notificação.
     */
    showNotification: function(type, message) {
        const container = document.getElementById("notificationContainer");
        if (!container) {
            console.warn("Elemento #notificationContainer não encontrado.");
            return;
        }
        const notification = document.createElement("div");
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 12px;">
                <i class="${Utils.getNotificationIcon(type)}"></i>
                <span>${message}</span>
            </div>
        `;
        container.appendChild(notification);
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, NOTIFICATION_CONFIG.duration);
    },

    /**
     * Retorna o ícone Font Awesome para o tipo de notificação.
     * @param {string} type - Tipo da notificação.
     * @returns {string}
     */
    getNotificationIcon: function(type) {
        const icons = {
            success: "fas fa-check-circle",
            error: "fas fa-exclamation-circle",
            warning: "fas fa-exclamation-triangle",
            info: "fas fa-info-circle"
        };
        return icons[type] || icons.info;
    }
};

// Expor Utils globalmente
window.Utils = Utils;
window.showNotification = Utils.showNotification; // Para compatibilidade com chamadas diretas
window.getNotificationIcon = Utils.getNotificationIcon; // Para compatibilidade com chamadas diretas

// Expor configurações globalmente
window.NOTIFICATION_CONFIG = NOTIFICATION_CONFIG;
window.API_CONFIG = API_CONFIG;
window.AUTH_CONFIG = AUTH_CONFIG;
window.MESSAGES = MESSAGES;


