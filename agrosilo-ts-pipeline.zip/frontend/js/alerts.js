/**
 * alerts.js
 * Gerencia a página de alertas do Agrosilo.
 * 
 * Funcionalidades:
 * - Carregar e exibir alertas do backend
 * - Filtrar alertas por nível, silo e período
 * - Paginação de alertas
 * - Marcar alertas como lidos/resolvidos
 */

// Variáveis globais
let allAlerts = [];
let currentFilters = {
    level: 'all',
    siloId: 'all',
    dateRange: 'all'
};
let currentPage = 1;
const alertsPerPage = 10;

// Inicialização da página
document.addEventListener('DOMContentLoaded', function() {
    // Verificar autenticação
    if (!requireAuth()) {
        return;
    }

    initializeAlertsPage();
});

/**
 * Inicializa a página de alertas
 */
async function initializeAlertsPage() {
    setupUserInterface();
    await loadSilosForFilter();
    await fetchAndRenderAlerts();
    setupEventHandlers();
}

/**
 * Configura a interface do usuário (header, user info)
 */
function setupUserInterface() {
    const user = getCurrentUser();
    document.getElementById('userName').textContent = user.name || 'Usuário';
    document.getElementById('userRole').textContent = user.role === 'admin' ? 'Administrador' : 'Usuário';
    if (isAdmin()) {
        document.getElementById('usersMenuItem').style.display = 'flex';
    }
}

/**
 * Carrega os silos para o filtro de silos
 */
async function loadSilosForFilter() {
    try {
        const silos = await authManager.makeRequest('/silos');
        const siloFilterSelect = document.getElementById('siloFilter');
        siloFilterSelect.innerHTML = '<option value="all">Todos os Silos</option>';
        silos.forEach(silo => {
            const option = document.createElement('option');
            option.value = silo._id;
            option.textContent = silo.name;
            siloFilterSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Erro ao carregar silos para filtro:', error);
        showNotification('error', 'Erro ao carregar silos para filtro.');
    }
}

/**
 * Busca alertas do backend e os renderiza
 */
async function fetchAndRenderAlerts() {
    try {
        const response = await authManager.makeRequest('/alerts');
        allAlerts = response.alerts || [];
        applyFilters(); // Aplica filtros e renderiza
    } catch (error) {
        console.error('Erro ao buscar alertas:', error);
        showNotification('error', 'Erro ao carregar alertas.');
        document.getElementById('allAlertsList').innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Não foi possível carregar os alertas</h3>
                <p>Verifique sua conexão ou tente novamente mais tarde.</p>
            </div>
        `;
    }
}

/**
 * Aplica os filtros selecionados e renderiza os alertas
 */
function applyFilters() {
    currentFilters.level = document.getElementById('alertLevelFilter').value;
    currentFilters.siloId = document.getElementById('siloFilter').value;
    currentFilters.dateRange = document.getElementById('dateRangeFilter').value;
    currentPage = 1; // Resetar para a primeira página ao aplicar filtros
    renderAlerts();
}

/**
 * Renderiza os alertas na interface
 */
function renderAlerts() {
    const alertsListContainer = document.getElementById('allAlertsList');
    let filteredAlerts = allAlerts.filter(alert => {
        const matchesLevel = currentFilters.level === 'all' || alert.alert.level === currentFilters.level;
        const matchesSilo = currentFilters.siloId === 'all' || alert.siloId === currentFilters.siloId;
        const matchesDate = filterByDateRange(alert.timestamp, currentFilters.dateRange);
        return matchesLevel && matchesSilo && matchesDate;
    });

    if (filteredAlerts.length === 0) {
        alertsListContainer.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-bell-slash"></i>
                <h3>Nenhum alerta encontrado</h3>
                <p>Nenhum alerta corresponde aos filtros selecionados.</p>
            </div>
        `;
        renderPagination(0);
        return;
    }

    const totalPages = Math.ceil(filteredAlerts.length / alertsPerPage);
    const startIndex = (currentPage - 1) * alertsPerPage;
    const endIndex = startIndex + alertsPerPage;
    const alertsToDisplay = filteredAlerts.slice(startIndex, endIndex);

    alertsListContainer.innerHTML = alertsToDisplay.map(alert => `
        <div class="alert-item ${alert.alert.level}">
            <div class="alert-icon ${alert.alert.level}">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="alert-content">
                <h4 class="alert-title">${alert.silo || 'Silo Desconhecido'} - ${Utils.getSensorDisplayName(alert.sensor)}</h4>
                <p class="alert-description">${alert.alert.message}</p>
            </div>
            <div class="alert-time">
                ${Utils.formatDate(alert.timestamp, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
            </div>
            <div class="alert-actions">
                <button class="btn btn-sm btn-outline" onclick="acknowledgeAlert('${alert._id}')">
                    <i class="fas fa-check"></i>
                    Marcar como Lido
                </button>
            </div>
        </div>
    `).join('');

    renderPagination(totalPages);
}

/**
 * Filtra alertas por período
 */
function filterByDateRange(timestamp, range) {
    const alertDate = new Date(timestamp);
    const now = new Date();
    switch (range) {
        case 'all':
            return true;
        case 'today':
            return alertDate.toDateString() === now.toDateString();
        case 'last7days':
            const sevenDaysAgo = new Date();
            sevenDaysAgo.setDate(now.getDate() - 7);
            return alertDate >= sevenDaysAgo;
        case 'last30days':
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(now.getDate() - 30);
            return alertDate >= thirtyDaysAgo;
        default:
            return true;
    }
}

/**
 * Renderiza os controles de paginação
 */
function renderPagination(totalPages) {
    const paginationContainer = document.getElementById('paginationControls');
    paginationContainer.innerHTML = '';

    if (totalPages <= 1) return;

    const prevButton = document.createElement('button');
    prevButton.className = 'btn btn-outline';
    prevButton.innerHTML = '<i class="fas fa-chevron-left"></i> Anterior';
    prevButton.disabled = currentPage === 1;
    prevButton.onclick = () => {
        currentPage--;
        renderAlerts();
    };
    paginationContainer.appendChild(prevButton);

    const pageInfo = document.createElement('span');
    pageInfo.className = 'page-info';
    pageInfo.textContent = `Página ${currentPage} de ${totalPages}`;
    paginationContainer.appendChild(pageInfo);

    const nextButton = document.createElement('button');
    nextButton.className = 'btn btn-outline';
    nextButton.innerHTML = 'Próximo <i class="fas fa-chevron-right"></i>';
    nextButton.disabled = currentPage === totalPages;
    nextButton.onclick = () => {
        currentPage++;
        renderAlerts();
    };
    paginationContainer.appendChild(nextButton);
}

/**
 * Marca um alerta como lido/resolvido
 */
async function acknowledgeAlert(alertId) {
    try {
        await authManager.makeRequest(`/alerts/${alertId}/acknowledge`, {
            method: 'PUT'
        });
        showNotification('success', 'Alerta marcado como lido.');
        // Remover o alerta da lista local e renderizar novamente
        allAlerts = allAlerts.filter(alert => alert._id !== alertId);
        renderAlerts();
        // Atualizar contagem de alertas no header
        updateAlertCount();
    } catch (error) {
        console.error('Erro ao marcar alerta como lido:', error);
        showNotification('error', 'Erro ao marcar alerta como lido.');
    }
}

/**
 * Atualiza a contagem de alertas no header (badge)
 */
function updateAlertCount() {
    const activeAlertsCount = allAlerts.filter(alert => !alert.acknowledged).length;
    document.getElementById('alertCount').textContent = activeAlertsCount;
    document.getElementById('alertCount').style.display = activeAlertsCount > 0 ? 'block' : 'none';
}

/**
 * Configura manipuladores de eventos para filtros e botões
 */
function setupEventHandlers() {
    document.getElementById('alertLevelFilter').addEventListener('change', applyFilters);
    document.getElementById('siloFilter').addEventListener('change', applyFilters);
    document.getElementById('dateRangeFilter').addEventListener('change', applyFilters);
}

/**
 * Função para atualizar alertas (chamada pelo botão de atualizar)
 */
function refreshAlerts() {
    fetchAndRenderAlerts();
    showNotification('info', 'Alertas atualizados.');
}

/**
 * Mostra notificação (função global, pode ser movida para utils.js)
 */
function showNotification(type, message) {
    const container = document.getElementById('notificationContainer');
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div style="display: flex; align-items: center; gap: 12px;">
            <i class="${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
    `;
    container.appendChild(notification);
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, NOTIFICATION_CONFIG.duration);
}

/**
 * Retorna ícone da notificação (função global, pode ser movida para utils.js)
 */
function getNotificationIcon(type) {
    const icons = {
        success: 'fas fa-check-circle',
        error: 'fas fa-exclamation-circle',
        warning: 'fas fa-exclamation-triangle',
        info: 'fas fa-info-circle'
    };
    return icons[type] || icons.info;
}


