# agrosilo-ts-pipeline/backend/app/services.py

from datetime import datetime, timezone
from typing import Iterable, List, Dict, Any
from .domain import IReadingRepository, ISensorRepository, Reading
import os

# REMOVA O BLOCO DE LEITURA DE OS.GETENV AQUI!
# REMOVIDO:
# TS_FIELD_TEMP = int(os.getenv("TS_FIELD_TEMP", 1))
# TS_FIELD_HUM = int(os.getenv("TS_FIELD_HUM", 2))
# TS_FETCH_RESULTS = int(os.getenv("TS_FETCH_RESULTS", 100))
# SILO_ID = os.getenv("SILO_ID")


class IngestService:
    def __init__(self, ts_client, sensor_repo: ISensorRepository, reading_repo: IReadingRepository):
        # Configurações injetadas
        self.ts = ts_client
        self.sensors = sensor_repo
        self.readings = reading_repo
        
        # AGORA, LEIA AS CONFIGURAÇÕES AQUI, USANDO OS.GETENV DIRETAMENTE:
        self.silo_id = os.getenv("SILO_ID")
        self.f_temp = int(os.getenv("TS_FIELD_TEMP", 1))
        self.f_hum = int(os.getenv("TS_FIELD_HUM", 2))
        self.results = int(os.getenv("TS_FETCH_RESULTS", 100))

        if not self.silo_id:
             # A validação permanece
             raise ValueError("SILO_ID deve ser definido no ambiente.")


    @staticmethod
    def _clean_temperature(v: float) -> bool:
        return v is not None and 0 <= v <= 60

    @staticmethod
    def _clean_humidity(v: float) -> bool:
        return v is not None and 0 <= v <= 100

    def _parse(self, raw: dict, field: int) -> tuple[datetime, float] | None:
        """Extrai timestamp e valor, tratando erros de tipo e formato."""
        v = raw.get(f"field{field}")
        if v in (None, ""): return None
        try:
            val = float(v)
        except:
            return None
            
        ts = datetime.fromisoformat(raw["created_at"].replace("Z", "+00:00")).replace(tzinfo=None)
        # O ThingSpeak já envia em UTC, então não precisamos do .astimezone(timezone.utc)
        # apenas a normalização (tzinfo=None) para salvar no Mongo.
        return ts, val

    async def _sync_one(self, sensor_type: str, field: int, validator) -> dict:
        """Sincroniza dados para um único tipo de sensor (ex: temperatura)."""
        
        # 1. Extração dos feeds
        feeds = await self.ts.fetch_field(field, self.results)
        
        if not feeds:
            return {"type": sensor_type, "received": 0, "stored": 0}

        # 2. Parsing e limpeza de valores (primeira etapa)
        parsed = [self._parse(f, field) for f in feeds]
        parsed = [(ts, val) for ts, val in parsed if ts and validator(val)]
        
        # 3. Regra simples anti-salto (mantida)
        parsed.sort(key=lambda x: x[0])
        cleaned_readings: List[Reading] = []
        
        # Aqui, você está comparando a variação do valor. O ideal seria fazer isso
        # depois de pegar o último valor do DB, mas vamos manter sua lógica de limpeza
        # que compara com o ponto anterior no feed.
        for i, (ts, val) in enumerate(parsed):
            # Limpeza anti-salto: se a variação for muito grande, ignora.
            if i > 0 and abs(val - parsed[i-1][1]) > (10 if sensor_type=="temperature" else 30):
                continue
            
            # 4. Obtém/Cria Sensor e Prepara para Inserção
            sensor = await self.sensors.get_or_create(self.silo_id, sensor_type)
            
            cleaned_readings.append(
                Reading(sensor_id=sensor.id, ts=ts, value=val)
            )

        # 5. Inserção no DB
        upserts = await self.readings.upsert_many(cleaned_readings) # upsert_many precisa receber uma lista de Readings
        
        return {"type": sensor_type, "received": len(feeds), "stored": upserts}


    async def sync_all(self) -> dict:
        """Sincroniza todos os tipos de sensores."""
        t = await self._sync_one("temperature", self.f_temp, self._clean_temperature)
        h = await self._sync_one("humidity", self.f_hum, self._clean_humidity)
        return {"temperature": t, "humidity": h}