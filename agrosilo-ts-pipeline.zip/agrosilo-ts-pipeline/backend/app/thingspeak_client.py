# agrosilo-ts-pipeline/backend/app/thingspeak_client.py
import httpx
import os
from typing import List, Dict, Any, Optional

class ThingSpeakClient:
    def __init__(self, base: str = "https://api.thingspeak.com"):
        self.base = base
        # Ler configurações do .env/ambiente
        self.channel_id = os.getenv("THINGSPEAK_CHANNEL_ID")
        self.api_key = os.getenv("THINGSPEAK_READ_API_KEY")

        if not self.channel_id or not self.api_key:
            raise ValueError(
                "THINGSPEAK_CHANNEL_ID ou THINGSPEAK_READ_API_KEY não definidos no ambiente."
            )

    async def fetch_field(self, field: int, results: int = 100) -> List[Dict[str, Any]]:
        """
        Extrai leituras de um campo específico, usando as credenciais do cliente.
        """
        url = f"{self.base}/channels/{self.channel_id}/fields/{field}.json"
        params = {"api_key": self.api_key, "results": results}
        
        # O cliente HTTPX deve ser gerenciado por async with para garantir que feche
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(url, params=params)
            r.raise_for_status()
            return r.json()["feeds"]  # lista de pontos