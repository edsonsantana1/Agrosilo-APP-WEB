from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI

def enable_cors(app: FastAPI):
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # ajuste se quiser restringir
        allow_methods=["*"],
        allow_headers=["*"],
    )
