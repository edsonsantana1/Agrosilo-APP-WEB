# agrosilo-ts-pipeline/backend/app/api.py
import os
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import asyncio 

from .thingspeak_client import ThingSpeakClient
from .repositories import SensorRepository, ReadingRepository
from .services import IngestService

# Variáveis globais e de Polling
global mongo_client, sensor_repo, reading_repo, ts_client, ingestion_service
polling_task: asyncio.Task = None

# Obtenha a frequência de polling do ambiente (antes da função create_app)
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "15"))

async def periodic_poll(ingestion_service):
    """Loop assíncrono para extração periódica de dados do ThingSpeak."""
    while True:
        try:
            print("--- [SCHEDULER] Iniciando ciclo de polling ---")
            await ingestion_service.sync_all() 
            print("--- [SCHEDULER] Fim do ciclo. Aguardando... ---")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"ERRO no ciclo de polling: {e}")
            await asyncio.sleep(POLL_SECONDS * 2) 
            continue
        
        await asyncio.sleep(POLL_SECONDS)

def create_app() -> FastAPI:
    app = FastAPI(title="Agrosilo Pipeline")

    # --- ADICIONE DE VOLTA O MIDDLEWARE DE CORS ---
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"], allow_headers=["*"], allow_methods=["*"]
    )
    
    # --- ADICIONE DE VOLTA A ROTA /health ---
    @app.get("/health")
    async def health(): 
        """Verifica se a API está online."""
        return {"ok": True}
    # ----------------------------------------


    # --- HANDLER DE STARTUP ---
    @app.on_event("startup")
    async def _startup_tasks():
        """Inicializa todos os serviços e INICIA O POLLING."""
        global mongo_client, sensor_repo, reading_repo, ts_client, ingestion_service, polling_task
        
        # 1. Conexão ao DB
        mongo_uri = os.getenv("MONGODB_URI")
        mongo_db  = os.getenv("MONGODB_DB", "test")
        mongo_client = AsyncIOMotorClient(mongo_uri)
        db = mongo_client[mongo_db]

        # 2. Inicialização dos Repositórios e Clientes
        sensor_repo  = SensorRepository(db)
        reading_repo = ReadingRepository(db)
        ts_client = ThingSpeakClient()
        
        # 3. Inicialização do Serviço de Ingestão (Assinatura correta)
        ingestion_service = IngestService(
            ts_client=ts_client,
            sensor_repo=sensor_repo,
            reading_repo=reading_repo,
        )

        # 4. Garante a coleção Timeseries
        await reading_repo.ensure_time_series()
        
        # --- INICIA A TAREFA DE POLLING ---
        polling_task = asyncio.create_task(periodic_poll(ingestion_service))
        print(f"INFO: Polling iniciado a cada {POLL_SECONDS} segundos.")

    # --- HANDLER DE SHUTDOWN ---
    @app.on_event("shutdown")
    async def _shutdown_tasks():
        """Fecha conexões e CANCELA O POLLING."""
        global mongo_client, polling_task
        if polling_task:
            polling_task.cancel()
            print("INFO: Polling Task cancelada.")
        if mongo_client:
            mongo_client.close()
            print("INFO: Conexão com MongoDB fechada.")

    # --- ROTAS DE API (você precisará ter as rotas /trigger-sync e /history aqui também) ---
    @app.post("/trigger-sync")
    async def trigger_sync():
        """Força a sincronização dos dados do ThingSpeak."""
        res = await ingestion_service.sync_all() 
        return JSONResponse(res)

    @app.get("/history")
    async def history(siloId: str, type: str, limit: int = 200):
        """Busca o histórico de leituras para um sensor."""
        sensor = await sensor_repo.get_or_create(siloId, type)
        data = await reading_repo.get_history(sensor.id, limit)
        
        return JSONResponse({
            "sensorId": sensor.id, 
            "type": sensor.type,
            "points": [{"t": d.ts, "v": d.value} for d in data]
        })
    # ---------------------------------------------------------------------------------------

    return app

app = create_app()