from typing import Protocol, List, Optional, Dict
from datetime import datetime
from pydantic import BaseModel, Field

# ------- Entidades (Domínio) -------

class Reading(BaseModel):
    sensor_id: str
    ts: datetime
    value: float

class Sensor(BaseModel):
    id: str
    silo_id: str
    type: str  # "temperature" | "humidity" | ...

# ------- Ports (Interfaces) -------

class IThingSpeakClient(Protocol):
    async def fetch_field(self, channel_id: str, field_number: int, api_key: str, results: int) -> List[Dict]:
        """Retorna lista de feeds do campo (cada feed é um dict com created_at, fieldX, etc.)."""

class ISensorRepository(Protocol):
    async def get_or_create(self, silo_id: str, sensor_type: str) -> Sensor: ...
    async def get_by_type(self, silo_id: str, sensor_type: str) -> Optional[Sensor]: ...

class IReadingRepository(Protocol):
    async def ensure_time_series(self) -> None: ...
    async def get_last_ts(self, sensor_id: str) -> Optional[datetime]: ...
    async def upsert_many(self, readings: List[Reading]) -> int: ...
    async def get_history(self, sensor_id: str, limit: int) -> List[Reading]: ...
