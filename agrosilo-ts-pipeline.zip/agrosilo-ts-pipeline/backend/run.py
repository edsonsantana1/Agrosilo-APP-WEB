# agrosilo-ts-pipeline/backend/run.py

import os
import uvicorn
from dotenv import load_dotenv
from app.api import create_app

# --- CORREÇÃO: Força o load_dotenv a procurar no diretório atual ---
# Isso garante que ele encontre o .env na pasta 'backend'
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), ".env"))

# O agendador deve ser movido para um handler de lifespan do FastAPI...

def main():
    app = create_app()
    
    # ... (restante do código main) ...
    uvicorn.run(
        app, 
        host=os.getenv("API_HOST", "0.0.0.0"), 
        port=int(os.getenv("API_PORT", "8000")), 
        log_level="info"
    )

if __name__ == "__main__":
    main()