// backend/services/thingspeakservice.js
const axios = require('axios');
const Sensor = require('../models/sensor');
const { Reading } = require('../models/reading');
const { processSensorData } = require('./alertService');

/**
 * Integração ThingSpeak (versão nova)
 * - Busca dados da API do ThingSpeak
 * - Sincroniza incrementalmente com a coleção "readings" (time-series)
 * - Processa alertas apenas para pontos novos
 */

const THINGSPEAK_CONFIG = {
  baseURL: 'https://api.thingspeak.com',
  readAPIKey: process.env.THINGSPEAK_READ_API_KEY,
  writeAPIKey: process.env.THINGSPEAK_WRITE_API_KEY,
  channelId: process.env.THINGSPEAK_CHANNEL_ID
};

/** Lê o canal completo */
async function fetchChannelData(channelId, apiKey, results = 100) {
  try {
    const { data } = await axios.get(
      `${THINGSPEAK_CONFIG.baseURL}/channels/${channelId}/feeds.json`,
      { params: { api_key: apiKey, results } }
    );
    return { success: true, channel: data.channel, feeds: data.feeds };
  } catch (err) {
    console.error('[thingspeak] fetchChannelData:', err.message);
    return { success: false, error: err.message };
  }
}

/** Lê um campo específico */
async function fetchFieldData(channelId, fieldNumber, apiKey, results = 100) {
  try {
    const { data } = await axios.get(
      `${THINGSPEAK_CONFIG.baseURL}/channels/${channelId}/fields/${fieldNumber}.json`,
      { params: { api_key: apiKey, results } }
    );
    return { success: true, feeds: data.feeds };
  } catch (err) {
    console.error(`[thingspeak] fetchFieldData f${fieldNumber}:`, err.message);
    return { success: false, error: err.message };
  }
}

/**
 * Sincroniza dados de UM sensor (incremental) para a coleção "readings"
 * - Busca últimos N pontos do ThingSpeak
 * - Compara com o último ts em readings
 * - Upsert apenas dos novos (bulkWrite, idempotente)
 */
async function syncSensorData(sensorId, channelId, fieldNumber, apiKey) {
  try {
    // 1) checa se o sensor existe
    const sensor = await Sensor.findById(sensorId).select('_id type').lean();
    if (!sensor) throw new Error('Sensor não encontrado');

    // 2) último timestamp salvo em readings
    const lastDoc = await Reading.findOne({ sensor: sensorId })
      .sort({ ts: -1 })
      .select({ ts: 1 })
      .lean();
    const lastTs = lastDoc?.ts || null;

    // 3) busca dados do ThingSpeak
    const thing = await fetchFieldData(channelId, fieldNumber, apiKey, 100);
    if (!thing.success) throw new Error(thing.error);

    // 4) filtra pontos novos
    const candidates = [];
    for (const feed of thing.feeds || []) {
      const raw = feed[`field${fieldNumber}`];
      if (raw === null || raw === undefined || raw === '') continue;

      const ts = new Date(feed.created_at);
      const val = Number(raw);
      if (!Number.isFinite(val)) continue;

      if (!lastTs || ts > lastTs) {
        candidates.push({ ts, value: val });
      }
    }

    if (!candidates.length) {
      return {
        success: true,
        sensorId,
        newDataPoints: 0,
        processedData: []
      };
    }

    // 5) ordena por timestamp (crescente)
    candidates.sort((a, b) => a.ts - b.ts);

    // 6) upsert idempotente em "readings"
    const ops = candidates.map(p => ({
      updateOne: {
        filter: { sensor: sensorId, ts: p.ts },
        update: { $setOnInsert: { sensor: sensorId, ts: p.ts, value: p.value } },
        upsert: true
      }
    }));

    const result = await Reading.bulkWrite(ops, { ordered: false });

    // 7) processa alertas (somente novos pontos)
    for (const p of candidates) {
      // eslint-disable-next-line no-await-in-loop
      await processSensorData(sensorId, p.value);
    }

    return {
      success: true,
      sensorId,
      newDataPoints: result.upsertedCount || 0,
      processedData: candidates
    };
  } catch (error) {
    console.error('[thingspeak] syncSensorData erro:', error);
    return { success: false, error: error.message };
  }
}

/** Sincroniza todos os sensores com config ThingSpeak */
async function syncAllSensors() {
  try {
    const sensors = await Sensor.find({
      'thingSpeakConfig.channelId': { $exists: true, $ne: null },
      'thingSpeakConfig.fieldNumber': { $exists: true, $ne: null }
    }).select({ _id: 1, thingSpeakConfig: 1 }).lean();

    const out = [];
    for (const s of sensors) {
      const { channelId, fieldNumber, apiKey } = s.thingSpeakConfig || {};
      // eslint-disable-next-line no-await-in-loop
      const r = await syncSensorData(
        s._id,
        channelId,
        fieldNumber,
        apiKey || THINGSPEAK_CONFIG.readAPIKey
      );
      out.push(r);
    }
    return out;
  } catch (err) {
    console.error('[thingspeak] syncAllSensors erro:', err);
    return [];
  }
}

/** Envia dados (write) para ThingSpeak */
async function sendDataToThingSpeak(channelId, writeAPIKey, data) {
  try {
    const { data: entryId } = await axios.post(
      `${THINGSPEAK_CONFIG.baseURL}/update.json`,
      { api_key: writeAPIKey, ...data }
    );
    return { success: true, entryId };
  } catch (err) {
    console.error('[thingspeak] sendDataToThingSpeak:', err.message);
    return { success: false, error: err.message };
  }
}

/** Info do canal */
async function getChannelInfo(channelId, apiKey) {
  try {
    const { data } = await axios.get(
      `${THINGSPEAK_CONFIG.baseURL}/channels/${channelId}.json`,
      { params: { api_key: apiKey } }
    );
    return { success: true, channel: data };
  } catch (err) {
    console.error('[thingspeak] getChannelInfo:', err.message);
    return { success: false, error: err.message };
  }
}

/** Configura sensor com channel/field do ThingSpeak */
async function configureSensorThingSpeak(sensorId, thingSpeakConfig) {
  try {
    const sensor = await Sensor.findById(sensorId);
    if (!sensor) throw new Error('Sensor não encontrado');

    const { channelId, fieldNumber, apiKey } = thingSpeakConfig;
    if (!channelId || !fieldNumber) throw new Error('channelId e fieldNumber são obrigatórios');

    const test = await getChannelInfo(channelId, apiKey || THINGSPEAK_CONFIG.readAPIKey);
    if (!test.success) throw new Error('Não foi possível conectar ao canal: ' + test.error);

    sensor.thingSpeakConfig = { channelId, fieldNumber, apiKey, lastSync: new Date() };
    await sensor.save();

    return { success: true, message: 'Sensor configurado com sucesso para ThingSpeak', channelInfo: test.channel };
  } catch (err) {
    console.error('[thingspeak] configureSensorThingSpeak:', err);
    return { success: false, error: err.message };
  }
}

/** Remove configuração do ThingSpeak */
async function removeSensorThingSpeakConfig(sensorId) {
  try {
    const sensor = await Sensor.findById(sensorId);
    if (!sensor) throw new Error('Sensor não encontrado');

    sensor.thingSpeakConfig = undefined;
    await sensor.save();

    return { success: true, message: 'Configuração do ThingSpeak removida com sucesso' };
  } catch (err) {
    console.error('[thingspeak] removeSensorThingSpeakConfig:', err);
    return { success: false, error: err.message };
  }
}

module.exports = {
  fetchChannelData,
  fetchFieldData,
  syncSensorData,
  syncAllSensors,
  sendDataToThingSpeak,
  getChannelInfo,
  configureSensorThingSpeak,
  removeSensorThingSpeakConfig,
  THINGSPEAK_CONFIG
};
