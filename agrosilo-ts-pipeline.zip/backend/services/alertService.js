// backend/services/alertService.js
const Sensor = require("../models/sensor");
const Silo   = require("../models/silo");
const User   = require("../models/user");
const { Reading } = require("../models/reading");

// ================== PARÂMETROS TÉCNICOS DE SEGURANÇA ==================
const SAFETY_PARAMETERS = {
  humidity: {
    acceptable: 14,
    safe: 13,
    insect_limit: 10,
    fungus_risk: 16
  },
  temperature: {
    slow_fungus: 15,
    medium_growth_min: 20,
    medium_growth_max: 30,
    high_risk_min: 40,
    high_risk_max: 55
  }
};

function checkHumidityAlert(humidity) {
  if (humidity > SAFETY_PARAMETERS.humidity.fungus_risk) {
    return {
      level: 'critical',
      message: `Umidade crítica: ${humidity}% - Risco explosivo de fungos (>${SAFETY_PARAMETERS.humidity.fungus_risk}%)`,
      recommendation: 'Ação imediata necessária para reduzir a umidade'
    };
  } else if (humidity > SAFETY_PARAMETERS.humidity.acceptable) {
    return {
      level: 'warning',
      message: `Umidade elevada: ${humidity}% - Acima do aceitável (${SAFETY_PARAMETERS.humidity.acceptable}%)`,
      recommendation: 'Monitorar de perto e considerar ações para reduzir a umidade'
    };
  } else if (humidity > SAFETY_PARAMETERS.humidity.safe) {
    return {
      level: 'caution',
      message: `Umidade moderada: ${humidity}% - Acima do nível seguro (${SAFETY_PARAMETERS.humidity.safe}%)`,
      recommendation: 'Manter monitoramento regular'
    };
  }
  return null;
}

function checkTemperatureAlert(temperature) {
  if (temperature >= SAFETY_PARAMETERS.temperature.high_risk_min &&
      temperature <= SAFETY_PARAMETERS.temperature.high_risk_max) {
    return {
      level: 'critical',
      message: `Temperatura crítica: ${temperature}°C - Crescimento máximo (${SAFETY_PARAMETERS.temperature.high_risk_min}°C a ${SAFETY_PARAMETERS.temperature.high_risk_max}°C)`,
      recommendation: 'Ação imediata para reduzir a temperatura'
    };
  } else if (temperature > SAFETY_PARAMETERS.temperature.high_risk_max) {
    return {
      level: 'critical',
      message: `Temperatura extremamente alta: ${temperature}°C - Acima de ${SAFETY_PARAMETERS.temperature.high_risk_max}°C`,
      recommendation: 'Ação emergencial necessária'
    };
  } else if (temperature >= SAFETY_PARAMETERS.temperature.medium_growth_min &&
             temperature <= SAFETY_PARAMETERS.temperature.medium_growth_max) {
    return {
      level: 'warning',
      message: `Temperatura elevada: ${temperature}°C (${SAFETY_PARAMETERS.temperature.medium_growth_min}°C a ${SAFETY_PARAMETERS.temperature.medium_growth_max}°C)`,
      recommendation: 'Monitorar de perto e considerar ventilação'
    };
  }
  return null;
}

/**
 * Avalia o novo valor (chamada pela ingestão /api/iot/readings).
 * Retorna o alerta calculado (se houver).
 */
async function processSensorData(sensorId, value) {
  try {
    const sensor = await Sensor.findById(sensorId).populate({
      path: 'silo',
      populate: { path: 'user' }
    });
    if (!sensor) throw new Error('Sensor não encontrado');

    let alert = null;
    switch (sensor.type) {
      case 'humidity':
        alert = checkHumidityAlert(value);
        break;
      case 'temperature':
        alert = checkTemperatureAlert(value);
        break;
      default:
        break;
    }

    return { success: true, alert, sensor, value };
  } catch (error) {
    console.error('Erro ao processar dados do sensor:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Lista os alertas ativos do usuário com base no ÚLTIMO DADO de cada sensor
 * (busca em `readings`, não em Sensor.data).
 */
async function getActiveAlerts(userId) {
  try {
    // 1) Sensores do usuário
    const silos = await Silo.find({ user: userId }).select('_id').lean();
    const siloIds = silos.map(s => s._id);
    if (!siloIds.length) return [];

    const sensors = await Sensor.find({ silo: { $in: siloIds } })
      .select('_id type silo')
      .lean();

    if (!sensors.length) return [];

    const sensorIds = sensors.map(s => s._id);

    // 2) Pega o último ponto de cada sensor via aggregate
    const lastBySensor = await Reading.aggregate([
      { $match: { sensor: { $in: sensorIds } } },
      { $sort: { sensor: 1, ts: -1 } },
      {
        $group: {
          _id: '$sensor',
          ts:   { $first: '$ts' },
          value:{ $first: '$value' }
        }
      }
    ]);

    if (!lastBySensor.length) return [];

    // 3) Index para lookup rápido
    const sensById = Object.fromEntries(sensors.map(s => [String(s._id), s]));
    const siloById = Object.fromEntries((await Silo.find({ _id: { $in: siloIds } })
      .select('_id name').lean())
      .map(s => [String(s._id), s.name || 'Silo']));

    // 4) Calcula alertas
    const alerts = [];
    for (const row of lastBySensor) {
      const sid = String(row._id);
      const sensor = sensById[sid];
      if (!sensor) continue;

      let alert = null;
      if (sensor.type === 'humidity')    alert = checkHumidityAlert(row.value);
      else if (sensor.type === 'temperature') alert = checkTemperatureAlert(row.value);

      if (alert) {
        alerts.push({
          silo: siloById[String(sensor.silo)] || 'Silo',
          siloId: sensor.silo,
          sensor: sensor.type,
          sensorId: sensor._id,
          value: row.value,
          timestamp: row.ts,
          alert
        });
      }
    }

    return alerts;
  } catch (error) {
    console.error('Erro ao buscar alertas ativos:', error);
    return [];
  }
}

module.exports = {
  processSensorData,
  getActiveAlerts,
  SAFETY_PARAMETERS,
  checkHumidityAlert,
  checkTemperatureAlert
};
