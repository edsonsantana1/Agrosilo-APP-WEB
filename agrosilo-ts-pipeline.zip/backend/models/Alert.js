// backend/models/Alert.js (Modelo Faltante)

const mongoose = require('mongoose');

const alertSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    siloId: { type: mongoose.Schema.Types.ObjectId, ref: 'Silo', required: true },
    sensorId: { type: mongoose.Schema.Types.ObjectId, ref: 'Sensor', required: true },
    siloName: { type: String, required: true },
    sensorType: { type: String, required: true },
    level: { type: String, enum: ['critical', 'warning', 'caution'], required: true },
    message: { type: String, required: true },
    recommendation: { type: String },
    value: { type: Number, required: true },
    timestamp: { type: Date, default: Date.now },
    // ESTE CAMPO É OBRIGATÓRIO para a funcionalidade do frontend
    acknowledged: { type: Boolean, default: false } 
});

module.exports = mongoose.model('Alert', alertSchema);