// models/sensor.js
const mongoose = require('mongoose');

const SensorSchema = new mongoose.Schema(
  {
    silo: { type: mongoose.Schema.Types.ObjectId, ref: 'Silo', required: true },
    type: {
      type: String,
      required: true,
      enum: ['temperature', 'humidity', 'pressure', 'co2'],
      index: true
    },

    // (OPCIONAL) cache local de últimos pontos para UI.
    // NÃO é a fonte de verdade. Não carrega por padrão.
    data: {
      type: [{
        value: { type: Number, required: true },
        timestamp: { type: Date, default: Date.now }
      }],
      select: false
    },

    thingSpeakConfig: {
      channelId:   { type: String },
      fieldNumber: { type: Number },
      apiKey:      { type: String },
      lastSync:    { type: Date }
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Sensor', SensorSchema);
