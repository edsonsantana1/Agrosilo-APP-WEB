const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const UserSchema = new mongoose.Schema({
  role: { type: String, required: true, enum: ['user', 'admin'] },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: { type: String },
  phoneNumber: { type: String },
  telegramChatId: { type: String },
  notificationsEnabled: { type: Boolean, default: true }
});

UserSchema.pre('save', async function(next) {
  if (this.isModified('password')) {
    this.password = await bcrypt.hash(this.password, 10);
  }
  next();
});

UserSchema.methods.comparePassword = function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('User', UserSchema);
