// backend/routes/analysisRoutes.js
const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');

const Silo = require('../models/silo');
const Sensor = require('../models/sensor');
const { SAFETY_PARAMETERS } = require('../services/alertService'); // mesmos limites dos alertas

// ----------------- utils de domínio -----------------
function getRangeStart(range) {
  const now = new Date();
  const r = String(range || '24h').toLowerCase();
  if (r === '24h') { const d = new Date(now); d.setHours(d.getHours() - 24); return d; }
  if (r === '7d')  { const d = new Date(now); d.setDate(d.getDate() - 7);   return d; }
  if (r === '30d') { const d = new Date(now); d.setDate(d.getDate() - 30);  return d; }
  return null; // all
}
const sensorLabel = (t) => ({
  temperature: 'Temperatura',
  humidity: 'Umidade',
  pressure: 'Pressão Atmosférica',
  co2: 'Gás CO2'
}[t] || t);

const sensorUnit  = (t) => ({
  temperature: '°C', humidity: '%', pressure: 'hPa', co2: 'ppm'
}[t] || '');

function basicStats(values) {
  const n = values.length;
  const sorted = [...values].sort((a,b)=>a-b);
  const sum = values.reduce((a,b)=>a+b,0);
  const mean = sum / n;
  const median = (n % 2)
    ? sorted[(n-1)/2]
    : (sorted[n/2 - 1] + sorted[n/2]) / 2;
  const p95 = sorted[Math.min(n-1, Math.floor(0.95 * (n-1)))];
  const min = sorted[0];
  const max = sorted[n-1];
  const variance = values.reduce((a,b)=>a + Math.pow(b-mean,2), 0) / (n > 1 ? (n-1) : 1);
  const stddev = Math.sqrt(variance);
  return { n, min, median, mean, p95, max, stddev };
}

function fmtBR(d) { return new Date(d).toLocaleString('pt-BR'); }

function complianceByBands(sensorType, points) {
  if (points.length < 2) return { normal:0, caution:0, warning:0, critical:0 };

  let bands;
  if (sensorType === 'humidity') {
    const p = SAFETY_PARAMETERS.humidity;
    bands = (v)=> v <= p.safe ? 'normal'
      : (v <= p.acceptable ? 'caution'
      : (v <= p.fungus_risk ? 'warning' : 'critical'));
  } else if (sensorType === 'temperature') {
    const p = SAFETY_PARAMETERS.temperature;
    bands = (v)=> {
      if (v >= p.high_risk_min && v <= p.high_risk_max) return 'critical';
      if (v >  p.high_risk_max) return 'critical';
      if (v >= p.medium_growth_min && v <= p.medium_growth_max) return 'warning';
      return 'normal';
    };
  } else {
    bands = ()=> 'normal';
  }

  const acc = { normal:0, caution:0, warning:0, critical:0 };
  for (let i=1;i<points.length;i++){
    const prev = points[i-1], cur = points[i];
    const dt = new Date(cur.timestamp) - new Date(prev.timestamp);
    const bucket = bands(prev.value);
    acc[bucket] += Math.max(0, dt);
  }
  return acc;
}

function msToHHMM(ms){
  const h = Math.floor(ms / 3600000);
  const m = Math.round((ms % 3600000) / 60000);
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
}

// reserva espaço; se faltar, quebra página
function ensureSpace(doc, needed, addGap = 8) {
  const bottom = doc.page.margins.bottom;
  const usable = doc.page.height - doc.y - bottom;
  if (usable < needed) doc.addPage();
  else doc.moveDown(addGap / 12);
}

// ----------------- rotas de dados p/ análise -----------------
router.get('/silos', async (req, res) => {
  try {
    const silos = await Silo.find({ user: req.user._id }).select('_id name').lean();
    res.json(silos);
  } catch (err) {
    console.error('[analysis/silos] erro:', err);
    res.status(500).json({ error: 'Erro ao carregar silos' });
  }
});

router.get('/history/:siloId/:sensorType', async (req, res) => {
  try {
    const { siloId, sensorType } = req.params;
    const { range = '24h' } = req.query;
    const silo = await Silo.findOne({ _id: siloId, user: req.user._id }).select('_id').lean();
    if (!silo) return res.status(404).json({ error: 'Silo não encontrado' });

    const sensors = await Sensor.find({ silo: siloId, type: sensorType }).select('_id data type').lean();
    if (!sensors?.length) return res.json([]);

    const start = getRangeStart(range);
    let points = [];
    for (const s of sensors) {
      if (!Array.isArray(s.data)) continue;
      for (const p of s.data) {
        if (!p || p.value == null || !p.timestamp) continue;
        if (start && new Date(p.timestamp) < start) continue;
        points.push({ timestamp: new Date(p.timestamp), value: Number(p.value), sensorId: s._id });
      }
    }
    points.sort((a,b)=>a.timestamp - b.timestamp);
    if (points.length > 5000) points = points.slice(-5000);
    res.json(points);
  } catch (err) {
    console.error('[analysis/history] erro:', err);
    res.status(500).json({ error: 'Erro ao carregar histórico' });
  }
});

// ----------------- PDF técnico -----------------
router.get('/report', async (req, res) => {
  try {
    const { siloId, sensorType, range = '24h', logoPath } = req.query;
    if (!siloId || !sensorType) {
      return res.status(400).json({ error: 'Parâmetros siloId e sensorType são obrigatórios' });
    }

    const silo = await Silo.findOne({ _id: siloId, user: req.user._id }).select('_id name').lean();
    if (!silo) return res.status(404).json({ error: 'Silo não encontrado' });

    const sensors = await Sensor.find({ silo: siloId, type: sensorType }).select('_id data type').lean();
    if (!sensors?.length) return res.status(404).json({ error: 'Nenhum sensor para este tipo' });

    const start = getRangeStart(range);
    let points = [];
    for (const s of sensors) {
      if (!Array.isArray(s.data)) continue;
      for (const p of s.data) {
        if (!p || p.value == null || !p.timestamp) continue;
        if (start && new Date(p.timestamp) < start) continue;
        points.push({ timestamp: new Date(p.timestamp), value: Number(p.value) });
      }
    }
    points.sort((a,b)=>a.timestamp - b.timestamp);
    if (!points.length) return res.status(404).json({ error: 'Sem dados no período selecionado' });

    const values = points.map(p => p.value);
    const stats = basicStats(values);
    const last = points[points.length-1];

    // delta 24h (se houver ponto próximo)
    const t24 = new Date(last.timestamp); t24.setHours(t24.getHours() - 24);
    const pivot = points.find(p => p.timestamp >= t24) || points[0];
    const delta24 = last.value - pivot.value;

    const bandsMs = complianceByBands(sensorType, points);
    const totalMs = Object.values(bandsMs).reduce((a,b)=>a+b,0) || 1;
    const pct = (ms)=> ((ms/totalMs)*100);

    // prepara PDF
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="agrosilo-relatorio-${Date.now()}.pdf"`);

    const doc = new PDFDocument({ size:'A4', margins:{ top:50, bottom:50, left:50, right:50 } });
    doc.pipe(res);

    // --- Header com logo
    const tryLogo = () => {
      try {
        const fallback = path.join(process.cwd(), 'backend', 'assets', 'logo.png');
        let file = fallback;
        if (logoPath) {
          const candidate = path.resolve(logoPath);
          if (fs.existsSync(candidate)) file = candidate;
        }
        if (fs.existsSync(file)) {
          doc.image(file, 50, 40, { width: 60 });
        }
      } catch(_) {}
    };

    tryLogo();
    doc.fillColor('#0c4a2e').fontSize(20).text('Relatório Técnico - Agrosilo', 120, 45);
    doc.moveDown(1.2);
    doc.fillColor('#111').fontSize(12)
      .text(`Silo: ${silo.name}`)
      .text(`Sensor: ${sensorLabel(sensorType)} (${sensorType})`)
      .text(`Período: ${String(range).toUpperCase()}`)
      .text(`Amostras: ${stats.n}`)
      .moveDown(0.7);

    // --- Resumo Executivo (cards)
    const startY = doc.y;
    const cardW = 250, cardH = 66, gap = 15, x1 = 50, x2 = 50 + cardW + gap;
    function card(x, y, title, value, color='#1f2937'){
      doc.roundedRect(x, y, cardW, cardH, 8).strokeColor('#e5e7eb').lineWidth(1).stroke();
      doc.fillColor('#6b7280').fontSize(10).text(title, x+12, y+10);
      doc.fillColor(color).fontSize(18).text(value, x+12, y+30);
      doc.fillColor('#111'); // reset
    }
    card(x1, startY, 'Valor atual', `${last.value.toFixed(2)} ${sensorUnit(sensorType)}`, '#0ea5e9');
    card(x2, startY, 'Variação 24h', `${delta24>=0?'+':''}${delta24.toFixed(2)} ${sensorUnit(sensorType)}`, delta24>=0?'#ef4444':'#22c55e');
    card(x1, startY+cardH+gap, 'Mediana (p50)', `${stats.median.toFixed(2)} ${sensorUnit(sensorType)}`);
    card(x2, startY+cardH+gap, 'p95', `${stats.p95.toFixed(2)} ${sensorUnit(sensorType)}`);
    doc.moveDown( (cardH*2 + gap + 10)/12 );

    // --- Estatísticas
    doc.addPage();
    doc.fontSize(14).fillColor('#0c4a2e').text('1. Estatísticas Descritivas', { underline:true });
    doc.moveDown(0.5);
    doc.fontSize(11).fillColor('#111')
      .text(`Mínimo:   ${stats.min.toFixed(2)} ${sensorUnit(sensorType)}`)
      .text(`Média:    ${stats.mean.toFixed(2)} ${sensorUnit(sensorType)}`)
      .text(`Mediana:  ${stats.median.toFixed(2)} ${sensorUnit(sensorType)}`)
      .text(`p95:      ${stats.p95.toFixed(2)} ${sensorUnit(sensorType)}`)
      .text(`Máximo:   ${stats.max.toFixed(2)} ${sensorUnit(sensorType)}`)
      .text(`Desvio-padrão: ${stats.stddev.toFixed(2)} ${sensorUnit(sensorType)}`)
      .moveDown(0.8);

    // --- Conformidade x faixas (garante ficar na mesma página)
    ensureSpace(doc, 140);
    doc.fontSize(14).fillColor('#0c4a2e').text('2. Distribuição por Faixas de Risco', { underline:true });
    doc.moveDown(0.5);
    const rows = [
      ['Faixa','Tempo (hh:mm)','%'],
      ['Normal',  msToHHMM(bandsMs.normal),  `${pct(bandsMs.normal).toFixed(1)}%`],
      ['Caution', msToHHMM(bandsMs.caution), `${pct(bandsMs.caution).toFixed(1)}%`],
      ['Warning', msToHHMM(bandsMs.warning), `${pct(bandsMs.warning).toFixed(1)}%`],
      ['Critical',msToHHMM(bandsMs.critical),`${pct(bandsMs.critical).toFixed(1)}%`],
    ];
    drawTable(doc, rows, { x:50, y:doc.y, colWidths:[180,180,100] });
    doc.moveDown(1);

    // --- Gráfico (minichart) que retorna base Y
    ensureSpace(doc, 220);
    doc.fontSize(14).fillColor('#0c4a2e').text('3. Série Temporal (Amostra)', { underline:true });
    doc.moveDown(0.5);
    const chartBottomY = drawMiniChart(doc, points, { x:50, y:doc.y, w:500, h:160, unit:sensorUnit(sensorType) });
    doc.y = chartBottomY + 16;

    // --- Amostra de leituras
    ensureSpace(doc, 300);
    doc.fontSize(14).fillColor('#0c4a2e').text('4. Amostra de Leituras', { underline:true });
    doc.moveDown(0.4);
    const head = ['Data/Hora','Valor'];
    const sampleStart = points.slice(0, 10).map(p => [fmtBR(p.timestamp), `${p.value.toFixed(2)} ${sensorUnit(sensorType)}`]);
    const sampleEnd   = points.slice(-10).map(p => [fmtBR(p.timestamp), `${p.value.toFixed(2)} ${sensorUnit(sensorType)}`]);
    drawTable(doc, [head, ...sampleStart, ...sampleEnd], { x:50, y:doc.y, colWidths:[300,180] });
    doc.moveDown(1);

    // --- Metodologia & Recomendações
    doc.addPage();
    doc.fontSize(14).fillColor('#0c4a2e').text('5. Metodologia', { underline:true }).moveDown(0.4);
    doc.fontSize(11).fillColor('#111')
      .text('• As leituras foram agregadas diretamente da base de dados (MongoDB) sincronizada via ThingSpeak.')
      .text('• Estatísticas calculadas: mínimo, média, mediana (p50), p95, máximo e desvio-padrão.')
      .text('• Conformidade por faixas usa os mesmos limites técnicos do módulo de alertas (SAFETY_PARAMETERS).')
      .text('• O gráfico representa a série com reamostragem visual (sem suavização).')
      .moveDown(0.8);

    const rec = buildRecommendations(sensorType, stats, pct(bandsMs.critical), pct(bandsMs.warning));
    doc.fontSize(14).fillColor('#0c4a2e').text('6. Recomendações Técnicas', { underline:true }).moveDown(0.4);
    doc.fontSize(11).fillColor('#111').text(rec);

    doc.moveDown(1);
    doc.fontSize(10).fillColor('#6b7280').text(`Gerado em: ${fmtBR(new Date())}`, { align:'right' });
    doc.end();

  } catch (err) {
    console.error('[analysis/report] erro:', err);
    res.status(500).json({ error: 'Erro ao gerar relatório' });
  }
});

// ----------------- helpers de desenho PDF -----------------
function drawTable(doc, rows, { x, y, colWidths }) {
  const rowH = 20;
  let cy = y;
  const isHeader = (i)=> i===0;

  for (let i=0;i<rows.length;i++){
    const row = rows[i];
    let cx = x;
    if (isHeader(i)) {
      doc.rect(x, cy, colWidths.reduce((a,b)=>a+b,0), rowH).fill('#f3f4f6');
      doc.fill('#111');
    }
    for (let c=0;c<row.length;c++){
      const w = colWidths[c] || 120;
      doc.rect(cx, cy, w, rowH).strokeColor('#e5e7eb').stroke();
      doc.fillColor(isHeader(i)?'#111':'#374151').fontSize(isHeader(i)?11:10)
        .text(String(row[c]), cx+6, cy+5, { width:w-12, ellipsis:true });
      cx += w;
    }
    cy += rowH;
    doc.fillColor('#111');
  }
}

function drawMiniChart(doc, points, { x, y, w, h, unit }) {
  if (points.length < 2) { 
    doc.text('Dados insuficientes para o gráfico.', x, y);
    return y + 14;
  }
  const vals = points.map(p=>p.value);
  const t0 = points[0].timestamp, t1 = points[points.length-1].timestamp;
  const min = Math.min(...vals), max = Math.max(...vals);
  const pad = 6;

  doc.rect(x, y, w, h).strokeColor('#e5e7eb').stroke();

  doc.moveTo(x+pad, y+h-pad).lineTo(x+w-pad, y+h-pad).strokeColor('#d1d5db').stroke();
  doc.moveTo(x+pad, y+pad).lineTo(x+pad, y+h-pad).strokeColor('#d1d5db').stroke();

  const sx = (ts)=> {
    const r = (ts - t0) / (t1 - t0 || 1);
    return x+pad + r*(w-2*pad);
  };
  const sy = (v)=> {
    const r = (v - min) / ((max-min)||1);
    return y+h-pad - r*(h-2*pad);
  };

  doc.moveTo(sx(points[0].timestamp), sy(points[0].value));
  for (let i=1;i<points.length;i++){
    doc.lineTo(sx(points[i].timestamp), sy(points[i].value));
  }
  doc.strokeColor('#0ea5e9').lineWidth(1.2).stroke();

  doc.fontSize(9).fillColor('#6b7280')
    .text(`${min.toFixed(2)} ${unit}`, x+4, sy(min)-10, { width: 80 })
    .text(`${max.toFixed(2)} ${unit}`, x+4, sy(max)-10, { width: 80 });
  doc.fillColor('#111');

  return y + h;
}

function buildRecommendations(sensorType, stats, pctCritical, pctWarning) {
  const lines = [];
  if (sensorType === 'humidity') {
    lines.push('- Umidade acima de limites eleva risco de fungos e insetos; priorize aeração e secagem.');
    if (pctCritical > 0) lines.push(`- Permanência em CRITICAL: ${pctCritical.toFixed(1)}%. Reduza imediatamente o teor de umidade (secagem/ventilação).`);
    if (pctWarning > 0)  lines.push(`- Tempo em WARNING: ${pctWarning.toFixed(1)}%. Ajuste parâmetros para manter ≤ níveis aceitáveis.`);
    lines.push(`- Variabilidade (σ): ${stats.stddev.toFixed(2)} — avalie oscilações de processo e infiltração.`);
  } else if (sensorType === 'temperature') {
    lines.push('- Temperaturas elevadas aceleram o crescimento de fungos; avalie ventilação e pontos quentes.');
    if (pctCritical > 0) lines.push(`- Permanência em CRITICAL: ${pctCritical.toFixed(1)}%. Investigue hotspots e avalie resfriamento forçado.`);
    if (pctWarning > 0)  lines.push(`- Tempo em WARNING: ${pctWarning.toFixed(1)}%. Melhore o balanceamento térmico e circulação de ar.`);
    lines.push(`- Variabilidade (σ): ${stats.stddev.toFixed(2)} — verifique estabilidade operacional.`);
  } else {
    lines.push('- Parâmetros dentro de faixas normativas na maior parte do tempo.');
    if (pctCritical > 0) lines.push(`- Atenção à permanência em CRITICAL: ${pctCritical.toFixed(1)}%.`);
  }
  return lines.join('\n');
}

module.exports = router;
