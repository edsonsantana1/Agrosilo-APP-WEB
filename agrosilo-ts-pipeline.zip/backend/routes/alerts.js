const express = require("express");
const router = express.Router();
const { auth } = require("../middleware/auth");
const { getActiveAlerts } = require("../services/alertService");

/**
 * Rotas para gerenciamento de alertas
 * 
 * Endpoints disponíveis:
 * - GET /api/alerts - Buscar alertas ativos do usuário
 * - GET /api/alerts/silo/:siloId - Buscar alertas de um silo específico
 * - GET /api/alerts/sensor/:sensorId - Buscar alertas de um sensor específico
 */

// Buscar todos os alertas ativos do usuário
router.get("/", auth, async (req, res) => {
    try {
        const alerts = await getActiveAlerts(req.user._id);
        res.send({
            success: true,
            count: alerts.length,
            alerts: alerts
        });
    } catch (error) {
        res.status(500).send({ 
            success: false,
            error: error.message 
        });
    }
});

// Buscar alertas de um silo específico
router.get("/silo/:siloId", auth, async (req, res) => {
    try {
        const allAlerts = await getActiveAlerts(req.user._id);
        const siloAlerts = allAlerts.filter(alert => 
            alert.siloId.toString() === req.params.siloId
        );
        
        res.send({
            success: true,
            siloId: req.params.siloId,
            count: siloAlerts.length,
            alerts: siloAlerts
        });
    } catch (error) {
        res.status(500).send({ 
            success: false,
            error: error.message 
        });
    }
});

// Buscar alertas de um sensor específico
router.get("/sensor/:sensorId", auth, async (req, res) => {
    try {
        const allAlerts = await getActiveAlerts(req.user._id);
        const sensorAlerts = allAlerts.filter(alert => 
            alert.sensorId.toString() === req.params.sensorId
        );
        
        res.send({
            success: true,
            sensorId: req.params.sensorId,
            count: sensorAlerts.length,
            alerts: sensorAlerts
        });
    } catch (error) {
        res.status(500).send({ 
            success: false,
            error: error.message 
        });
    }
});

module.exports = router;

